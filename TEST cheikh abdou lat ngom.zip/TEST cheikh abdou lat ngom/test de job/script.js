const showPassword = document.querySelector("#show-password");
const passwordField = document.querySelector("#floatingPassword");
showPassword.addEventListener("click", function(){
    this.classList.toggle("fa-eye-slash");
    const type = passwordField.getAttribute("type")
    === "password" ? "test" : "password";
    passwordField.setAttribute("type",type);

})

const showPassword1 = document.querySelector("#show-password1");
const passwordField1 = document.querySelector("#floatingPassword1");
showPassword1.addEventListener("click", function(){
    this.classList.toggle("fa-eye-slash");
    const type = passwordField1.getAttribute("type")
    === "password" ? "test" : "password";
    passwordField1.setAttribute("type",type);

})


